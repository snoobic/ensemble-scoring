# include "xtool.h"

// ***************************************************************************
// Pre-screening the given molecules with chemical rules 
// it also fixes the problems in the given Mol2 files
// latest update: 11/04/2004
// ***************************************************************************
int Xtool_Prescreen()
{
 extern Input *input;
 extern ForceField *ff;
 FILE *fin,*fout,*flog;
 int i,total,valid,count;
 bool mark;
 char format[10];
 Molecule mol;

 printf("Now reading parameters from '%s' ...\n",input->parameter_dir);
 ff=new ForceField(input->parameter_dir);
 if(ff==NULL) Memory_Allocation_Error("Xtool_Prescreen()");

 printf("Now reading the input Mol2 file from '%s' ...\n", input->input_file);

 total=Check_Mol2_File(input->input_file);

 if(total==0)
	{
	 printf("Error: no valid molecule is found in %s\n",input->input_file);
	 exit(1);
	}

 if((fin=fopen(input->input_file,"r"))==NULL) 
	Open_File_Error(input->input_file);

 if((fout=fopen(input->output_file,"w"))==NULL)
	Open_File_Error(input->output_file);

 if(strcmp(input->log_file,"none"))
	{
 	 if((flog=fopen(input->log_file,"w"))==NULL)
        	Open_File_Error(input->log_file);

	 fprintf(flog,"Serial#: status, Formula, Weight, logP, HB_atom, Rotor, Name\n");
	}
 else flog=NULL;

 sprintf(format,"%%-%dd ", (int)log10((float)total)+1);

 valid=0; count=0;

 for(i=0;i<total;i++)
	{
	 mol.Clear();

	 if(mol.Read_From_Mol2(fin)==FALSE) continue;

	 printf("Now processing %s ... \n", mol.name);

	 if(mol.Value_Atom()==FALSE)
		{
		 printf("This molecule is skipped.\n");
		 continue;
		}

	 count++;

	 mark=true;  // if this molecule is a valid one

	 if(!strcmp(((PRESCREEN_Input *)input)->apply_chemical_rules,"YES"))
		{
		 mol.logp=mol.Calculate_LogP();
		 mol.num_hb_atom=mol.Get_Num_HB_Atom();
		 mol.num_rotor=(int)mol.Count_Rotor();

		 if(mol.Chemical_Viability_Check()==FALSE) mark=false;
		}

	 if(flog!=NULL)
		{
		 fprintf(flog, format, count);

		 if(mark==true) fprintf(flog,"yes ");
		 else fprintf(flog,"no  ");

	 	 fprintf(flog,"%-15s ", mol.formula);
	 	 fprintf(flog,"%6.1f ", mol.weight);
	 	 fprintf(flog,"%6.2f ", mol.logp);
		 fprintf(flog,"%2d ", mol.num_hb_atom);
		 fprintf(flog,"%2d  ", mol.num_rotor);
	 	 fprintf(flog,"%-s\n", mol.name);
		}

	 if(mark==true) {mol.Write_Out_Mol2(fout); valid++;}
	 else continue;
	}

 printf("\nA total of %d molecules are found in %s\n", 
	total,input->input_file);

 printf("%d of them are valid structures.\n", count);

 if(flog!=NULL)
	{
	 printf("Information of each of them is summarized in %s\n",
		input->log_file);

	 fclose(flog);
	}

 printf("%d of them meet the chemical rules you set,\n", valid);
 printf("and they have been saved in %s\n", input->output_file);

 fclose(fin); fclose(fout); return TRUE;
}

// ***************************************************************************
// read in a PDB file and write out a XTOOL/PDB file (polar-H only)
// latest update: 11/06/2003
// ***************************************************************************
int Xtool_Fix_PDB()
{
 extern Input *input;
 extern ForceField *ff;
 extern Protein *protein;
 int i;

 ff=new ForceField(input->parameter_dir);
 if(ff==NULL) Memory_Allocation_Error("Xtool_Fix_PDB()");

 protein=new Protein;
 if(protein==NULL) Memory_Allocation_Error("Xtool_Fix_PDB()");

 printf("Now reading the input PDB file from '%s' ...\n", input->input_file);
 protein->Read_From_PDB(input->input_file); 

 printf("Now analyzing the structure ...\n");

 protein->Value_Atom(0);                      // do not calculate HB root

 // disable non-polar hydrogen atoms

 for(i=0;i<protein->num_atom;i++)
        {
         if(strcmp(protein->atom[i].xtype,"H")) continue;
         else protein->atom[i].valid=0;
        }

 protein->Refine_Structure();
 protein->Rearrange_IDs();

 printf("Now writing the fixed PDB file to '%s' ...\n", input->output_file);
 protein->Write_Out_PDB(input->output_file);

 return TRUE;
}

// ***************************************************************************
// read in a Mol2 file and write out a XTOOL/Mol2 file
// latest update: 11/06/2003
// ***************************************************************************
int Xtool_Fix_Mol2()
{
 extern Input *input;
 extern ForceField *ff;
 FILE *fin,*fout;
 int i,total,valid;
 Molecule mol;

 ff=new ForceField(input->parameter_dir);
 if(ff==NULL) Memory_Allocation_Error("Xtool_Fix_Mol2()");

 printf("Now reading the input Mol2 file from '%s' ...\n", input->input_file);

 total=Check_Mol2_File(input->input_file);

 if(total==0)
	{
	 puts("Error: no valid ligand molecule is given.");
	 exit(1);
	}

 if((fin=fopen(input->input_file,"r"))==NULL) 
	Open_File_Error(input->input_file);

 if((fout=fopen(input->output_file,"w"))==NULL)
	Open_File_Error(input->output_file);

 valid=0;

 for(i=0;i<total;i++)
	{
	 if(mol.Read_From_Mol2(fin)==FALSE) continue;

	 printf("Now processing %s ... \n", mol.name);

	 if(mol.Value_Atom()==FALSE)
		{
		 printf("This molecule is skipped.\n");
		}
	 else 
		{
		 mol.Write_Out_Mol2(fout); valid++;
		}
	}

 printf("%d molecules have been processed; %d are valid.\n", total, valid);

 printf("A new Mol2 file '%s' has been created.\n", input->output_file);

 fclose(fin); fclose(fout); return TRUE;
}

// ***************************************************************************
// service function for X-Score
// latest update: 03/28/2008
// ***************************************************************************
int Xtool_Test()
{
 extern Input *input;
 extern ForceField *ff;
 extern Protein *protein;
 extern Ligand *ligand;

 FILE *findex,*fout;
 int i,count;
 char line[256],dirname[256],filename[256],pdb_entry[10];
 float resolution,pkd_exp;

 printf("Now reading parameters from '%s' ...\n",input->parameter_dir);
 ff=new ForceField(input->parameter_dir);
 if(ff==NULL) Memory_Allocation_Error();

 ligand=new Ligand; if(ligand==NULL) Memory_Allocation_Error();
 protein=new Protein; if(protein==NULL) Memory_Allocation_Error();

 // findex=fopen("todo.lis","r"); fout=fopen("TERMS.xscore","w");
 findex=fopen("test.lis","r"); fout=fopen("TERMS.test","w");

 // fprintf(fout,"PDB    EXP    VDW     HB     HP     HM    HS      RT   C0\n");

 count=0;

 while(fgets(line,256,findex))
	{
	 if(line[0]=='#') continue;
	 sscanf(line,"%s%f%*s%f", pdb_entry, &resolution, &pkd_exp);
	                                                                                 printf("Now processing %4s ... %s\n", pdb_entry, Get_Time());
	 sprintf(dirname,"/home/wangrx/work/dataset/%s", pdb_entry);

	 sprintf(filename,"%s/%4s_ligand.mol2",dirname,pdb_entry);
	 ligand->Read_From_Mol2(filename);
 	 ligand->Value_Atom();

	 sprintf(filename,"%s/%4s_protein.pdb",dirname,pdb_entry);
	 protein->Read_From_PDB(filename);
	 protein->Value_Atom(); 

	 protein->Define_Pocket(ligand,10.0); 

	 sprintf(filename,"../dataset/%4s_pocket.xtool",pdb_entry);
	 protein->Write_Pocket_XTOOL(filename); 

	 // sprintf(filename,"../dataset/%4s_pocket.xtool",pdb_entry);
	 // protein->Read_Pocket_XTOOL(filename);

	 ligand->Assign_Apparent_Charge();
	 ligand->Generate_Surface_Dots(WATER_R);

	 ligand->vdw=ligand->Calculate_VDW();
	 ligand->hb=ligand->Calculate_HB();
	 ligand->hp=ligand->Calculate_HP();
	 ligand->hm=ligand->Calculate_HM();
	 ligand->hs=ligand->Calculate_HS();
	 ligand->rt=ligand->Calculate_RT();

	 fprintf(fout,"%4s  ", pdb_entry);
	 fprintf(fout,"%5.2f  ", pkd_exp);
	 fprintf(fout,"%6.1f  ", ligand->vdw);  
	 fprintf(fout,"%5.2f  ", ligand->hb);  
	 fprintf(fout,"%5.1f  ", ligand->hp);  
	 fprintf(fout,"%5.2f  ", ligand->hm);  
	 fprintf(fout,"%5.1f  ", ligand->hs);  
	 fprintf(fout,"%4.1f  ", ligand->rt);  
	 fprintf(fout,"1.00\n");

	 count++; fflush(fout);
	}

 printf("A total of %d samples have been processed.\n",count);

 fclose(findex); fclose(fout); return TRUE;
}
